export default function Dashboard() {
  return (
    <div style={{ 
      fontFamily: 'sans-serif', 
      padding: '50px', 
      textAlign: 'center' 
    }}>
      <h1>Your TrustBooster Dashboard</h1>
      <p>This is where you’ll send Google Review requests.</p>
    </div>
  );
}