export default function Home() {
  return (
    <div style={{ 
      fontFamily: 'sans-serif', 
      padding: '50px', 
      textAlign: 'center' 
    }}>
      <h1>Welcome to TrustBooster 🚀</h1>
      <p>All you need is a laptop & $100 to get started.</p>
      <a 
        href="/dashboard" 
        style={{ 
          display: 'inline-block', 
          marginTop: '20px', 
          padding: '10px 20px', 
          backgroundColor: '#0070f3', 
          color: '#fff', 
          borderRadius: '5px',
          textDecoration: 'none'
        }}>
        Get Started
      </a>
    </div>
  );
}